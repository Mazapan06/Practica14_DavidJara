#include "pico/stdlib.h"
#include "hardware/gpio.h"

// Definiciones de pines

// Semáforo Vehicular 1
#define VEHICULAR1_VERDE 2
#define VEHICULAR1_AMARILLO 3
#define VEHICULAR1_ROJO 4

// Semáforo Vehicular 2
#define VEHICULAR2_VERDE 5
#define VEHICULAR2_AMARILLO 6
#define VEHICULAR2_ROJO 7

// Semáforo Peatonal 1
#define PEATONAL1_ROJO 8
#define PEATONAL1_VERDE 9

// Semáforo Peatonal 2
#define PEATONAL2_ROJO 10
#define PEATONAL2_VERDE 11

// Display 7 segmentos 1
#define P1_SEG_A 12
#define P1_SEG_B 13
#define P1_SEG_C 14
#define P1_SEG_D 15
#define P1_SEG_E 16
#define P1_SEG_F 17
#define P1_SEG_G 18

// Display 7 segmentos 2
#define P2_SEG_A 19
#define P2_SEG_B 20
#define P2_SEG_C 21
#define P2_SEG_D 22
#define P2_SEG_E 26
#define P2_SEG_F 27
#define P2_SEG_G 28

// Botones
#define BOTON1 0
#define BOTON2 1

// Tabla de segmentos para los números 0-9
const uint8_t digitos[10][7] = {
    {1,1,1,1,1,1,0}, // 0
    {0,1,1,0,0,0,0}, // 1
    {1,1,0,1,1,0,1}, // 2
    {1,1,1,1,0,0,1}, // 3
    {0,1,1,0,0,1,1}, // 4
    {1,0,1,1,0,1,1}, // 5
    {1,0,1,1,1,1,1}, // 6
    {1,1,1,0,0,0,0}, // 7
    {1,1,1,1,1,1,1}, // 8
    {1,1,1,1,0,1,1}  // 9
};

// Función para inicializar pines
void inicializar_gpio() {
    // Vehiculares
    gpio_init(VEHICULAR1_VERDE); gpio_set_dir(VEHICULAR1_VERDE, GPIO_OUT);
    gpio_init(VEHICULAR1_AMARILLO); gpio_set_dir(VEHICULAR1_AMARILLO, GPIO_OUT);
    gpio_init(VEHICULAR1_ROJO); gpio_set_dir(VEHICULAR1_ROJO, GPIO_OUT);

    gpio_init(VEHICULAR2_VERDE); gpio_set_dir(VEHICULAR2_VERDE, GPIO_OUT);
    gpio_init(VEHICULAR2_AMARILLO); gpio_set_dir(VEHICULAR2_AMARILLO, GPIO_OUT);
    gpio_init(VEHICULAR2_ROJO); gpio_set_dir(VEHICULAR2_ROJO, GPIO_OUT);

    // Peatonales
    gpio_init(PEATONAL1_ROJO); gpio_set_dir(PEATONAL1_ROJO, GPIO_OUT);
    gpio_init(PEATONAL1_VERDE); gpio_set_dir(PEATONAL1_VERDE, GPIO_OUT);

    gpio_init(PEATONAL2_ROJO); gpio_set_dir(PEATONAL2_ROJO, GPIO_OUT);
    gpio_init(PEATONAL2_VERDE); gpio_set_dir(PEATONAL2_VERDE, GPIO_OUT);

    // Displays
    uint8_t pines_display1[] = {P1_SEG_A, P1_SEG_B, P1_SEG_C, P1_SEG_D, P1_SEG_E, P1_SEG_F, P1_SEG_G};
    uint8_t pines_display2[] = {P2_SEG_A, P2_SEG_B, P2_SEG_C, P2_SEG_D, P2_SEG_E, P2_SEG_F, P2_SEG_G};

    for (int i = 0; i < 7; i++) {
        gpio_init(pines_display1[i]);
        gpio_set_dir(pines_display1[i], GPIO_OUT);
        gpio_init(pines_display2[i]);
        gpio_set_dir(pines_display2[i], GPIO_OUT);
    }

    // Botones (pull-up)
    gpio_init(BOTON1); gpio_set_dir(BOTON1, GPIO_IN); gpio_pull_up(BOTON1);
    gpio_init(BOTON2); gpio_set_dir(BOTON2, GPIO_IN); gpio_pull_up(BOTON2);
}

// Función para mostrar número en un display
void mostrarNumero(int display, int numero) {
    uint8_t *pines;
    if (display == 1) {
        static uint8_t pines_display1[7] = {P1_SEG_A, P1_SEG_B, P1_SEG_C, P1_SEG_D, P1_SEG_E, P1_SEG_F, P1_SEG_G};
        pines = pines_display1;
    } else {
        static uint8_t pines_display2[7] = {P2_SEG_A, P2_SEG_B, P2_SEG_C, P2_SEG_D, P2_SEG_E, P2_SEG_F, P2_SEG_G};
        pines = pines_display2;
    }
    for (int i = 0; i < 7; i++) {
        gpio_put(pines[i], !digitos[numero][i]);
    }
}

// Función paquete vehicular
void semaforosVehiculares() {
    static absolute_time_t last_change;
    static int estado = 0;

    if (absolute_time_diff_us(last_change, get_absolute_time()) >= 5000000) { // 5 segundos por estado
        last_change = get_absolute_time();
        estado = (estado + 1) % 4;

        switch (estado) {
            case 0: // Vehicular1 Verde, Vehicular2 Rojo
                gpio_put(VEHICULAR1_VERDE, 1);
                gpio_put(VEHICULAR1_AMARILLO, 0);
                gpio_put(VEHICULAR1_ROJO, 0);

                gpio_put(VEHICULAR2_VERDE, 0);
                gpio_put(VEHICULAR2_AMARILLO, 0);
                gpio_put(VEHICULAR2_ROJO, 1);
                break;

            case 1: // Vehicular1 Amarillo, Vehicular2 Rojo
                gpio_put(VEHICULAR1_VERDE, 0);
                gpio_put(VEHICULAR1_AMARILLO, 1);
                gpio_put(VEHICULAR1_ROJO, 0);

                gpio_put(VEHICULAR2_VERDE, 0);
                gpio_put(VEHICULAR2_AMARILLO, 0);
                gpio_put(VEHICULAR2_ROJO, 1);
                break;

            case 2: // Vehicular1 Rojo, Vehicular2 Verde
                gpio_put(VEHICULAR1_VERDE, 0);
                gpio_put(VEHICULAR1_AMARILLO, 0);
                gpio_put(VEHICULAR1_ROJO, 1);

                gpio_put(VEHICULAR2_VERDE, 1);
                gpio_put(VEHICULAR2_AMARILLO, 0);
                gpio_put(VEHICULAR2_ROJO, 0);
                break;

            case 3: // Vehicular1 Rojo, Vehicular2 Amarillo
                gpio_put(VEHICULAR1_VERDE, 0);
                gpio_put(VEHICULAR1_AMARILLO, 0);
                gpio_put(VEHICULAR1_ROJO, 1);

                gpio_put(VEHICULAR2_VERDE, 0);
                gpio_put(VEHICULAR2_AMARILLO, 1);
                gpio_put(VEHICULAR2_ROJO, 0);
                break;
        }
    }
}

// Función paquete peatonal
void peatonalHandler(int boton, int display, int led_verde, int led_rojo) {
    if (gpio_get(boton) == 0) {
        gpio_put(led_rojo, 0);
        gpio_put(led_verde, 1);
        for (int i = 9; i >= 0; i--) {
            mostrarNumero(display, i);
            sleep_ms(1000);
        }
        gpio_put(led_verde, 0);
        gpio_put(led_rojo, 1);
        mostrarNumero(display, 0);
    }
}

int main() {
    stdio_init_all();
    inicializar_gpio();

    // Inicialización
    mostrarNumero(1, 0);
    mostrarNumero(2, 0);
    gpio_put(PEATONAL1_ROJO, 1);
    gpio_put(PEATONAL1_VERDE, 0);
    gpio_put(PEATONAL2_ROJO, 1);
    gpio_put(PEATONAL2_VERDE, 0);

    while (true) {
        semaforosVehiculares();                  // 🚦 Vehicular
        peatonalHandler(BOTON1, 1, PEATONAL1_VERDE, PEATONAL1_ROJO); // 🚶‍♂ Peatonal 1
        peatonalHandler(BOTON2, 2, PEATONAL2_VERDE, PEATONAL2_ROJO); // 🚶‍♀ Peatonal 2
        sleep_ms(10); // Para no saturar el CPU
    }
}